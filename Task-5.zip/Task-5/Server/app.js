const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
});

app.use(bodyParser.json());
app.use(express.static('public'));

// Middleware for authentication
const authenticateJWT = (req, res, next) => {
    const token = req.header('Authorization');
    if (!token) return res.status(401).json({ message: 'Authentication required' });
    
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: 'Access denied' });
        req.user = user;
        next();
    });
};

// Registration route
app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    try {
        const result = await pool.query(
            'INSERT INTO users (name, email, password) VALUES ($1, $2, $3) RETURNING *',
            [name, email, hashedPassword]
        );
        res.status(201).json({ message: 'User registered successfully', user: result.rows[0] });
    } catch (error) {
        res.status(400).json({ message: 'Error registering user', error });
    }
});

// Login route
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    
    try {
        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        const user = result.rows[0];
        
        if (!user || user.is_deleted) return res.status(400).json({ message: 'Invalid credentials or user deleted' });
        
        const validPassword = await bcrypt.compare(password, user.password);
        
        if (!validPassword) return res.status(400).json({ message: 'Invalid credentials' });
        
        const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    } catch (error) {
        res.status(400).json({ message: 'Error logging in', error });
    }
});

// Get all users (admin)
app.get('/users', authenticateJWT, async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM users WHERE is_deleted = FALSE ORDER BY last_login DESC');
        res.json(result.rows);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching users', error });
    }
});

// Block user
app.post('/block/:id', authenticateJWT, async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('UPDATE users SET status = $1 WHERE id = $2', ['blocked', id]);
        res.json({ message: 'User blocked successfully' });
    } catch (error) {
        res.status(400).json({ message: 'Error blocking user', error });
    }
});

// Unblock user
app.post('/unblock/:id', authenticateJWT, async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('UPDATE users SET status = $1 WHERE id = $2', ['active', id]);
        res.json({ message: 'User unblocked successfully' });
    } catch (error) {
        res.status(400).json({ message: 'Error unblocking user', error });
    }
});

// Delete user
app.delete('/delete/:id', authenticateJWT, async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('UPDATE users SET is_deleted = TRUE WHERE id = $1', [id]);
        res.json({ message: 'User deleted successfully' });
    } catch (error) {
        res.status(400).json({ message: 'Error deleting user', error });
    }
});

app.listen(process.env.PORT || 3000, () => {
    console.log('Server running');
});
