// Fetch and display users
async function fetchUsers() {
    const response = await axios.get('/users', { headers: { 'Authorization': 'Bearer ' + localStorage.getItem('token') } });
    const users = response.data;
    const tableBody = document.getElementById('userTable');
    tableBody.innerHTML = '';
    users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><input type="checkbox" class="userCheckbox" data-id="${user.id}"></td>
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>${user.last_login ? new Date(user.last_login).toLocaleString() : 'N/A'}</td>
            <td>${user.status}</td>
        `;
        tableBody.appendChild(row);
    });
}

// Handle select/deselect all
document.getElementById('selectAll').addEventListener('click', function() {
    const checkboxes = document.querySelectorAll('.userCheckbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = this.checked;
    });
});

// Block selected users
document.getElementById('blockBtn').addEventListener('click', async () => {
    const selectedIds = [...document.querySelectorAll('.userCheckbox:checked')].map(checkbox => checkbox.dataset.id);
    for (const id of selectedIds) {
        await axios.post(`/block/${id}`, {}, { headers: { 'Authorization': 'Bearer ' + localStorage.getItem('token') } });
    }
    fetchUsers();
});

// Unblock selected users
document.getElementById('unblockBtn').addEventListener('click', async () => {
    const selectedIds = [...document.querySelectorAll('.userCheckbox:checked')].map(checkbox => checkbox.dataset.id);
    for (const id of selectedIds) {
        await axios.post(`/unblock/${id}`, {}, { headers: { 'Authorization': 'Bearer ' + localStorage.getItem('token') } });
    }
    fetchUsers();
});

// Delete selected users
document.getElementById('deleteBtn').addEventListener('click', async () => {
    const selectedIds = [...document.querySelectorAll('.userCheckbox:checked')].map(checkbox => checkbox.dataset.id);
    for (const id of selectedIds) {
        await axios.delete(`/delete/${id}`, { headers: { 'Authorization': 'Bearer ' + localStorage.getItem('token') } });
    }
    fetchUsers();
});

fetchUsers();
